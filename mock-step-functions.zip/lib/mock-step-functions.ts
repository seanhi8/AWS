
// lib/mock-step-functions.ts
import { Stack, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as sfn from 'aws-cdk-lib/aws-stepfunctions';

export class MockStepFunctionsStack extends Stack {
  public readonly stateMachines: sfn.StateMachine[] = [];

  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    for (let i = 1; i <= 5; i++) {
      const stateMachine = new sfn.StateMachine(this, `Step${i}`, {
        stateMachineName: `mock-step-${i}`,
        definition: new sfn.Pass(this, `Pass${i}`, {
          result: sfn.Result.fromString(`Step ${i} Complete`),
          resultPath: '$.result',
        }),
      });
      this.stateMachines.push(stateMachine);
    }
  }
}
