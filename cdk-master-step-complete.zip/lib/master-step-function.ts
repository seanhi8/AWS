// lib/master-step-function.ts
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as sfn from 'aws-cdk-lib/aws-stepfunctions';
import * as tasks from 'aws-cdk-lib/aws-stepfunctions-tasks';
import * as iam from 'aws-cdk-lib/aws-iam';

interface MasterStepFunctionProps {
  step1Arn: string;
  step2Arn: string;
  step3Arn: string;
  step4Arn: string;
  step5Arn: string;
  bucket001: string;
  bucket002: string;
  bucket003: string;
}

export class MasterStepFunctionStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: MasterStepFunctionProps) {
    super(scope, id);

    const checkS3LambdaRole = new iam.Role(this, 'CheckS3LambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      inlinePolicies: {
        LambdaS3Policy: new iam.PolicyDocument({
          statements: [
            new iam.PolicyStatement({
              actions: ['s3:ListBucket'],
              resources: [
                `arn:aws:s3:::${props.bucket001}`,
                `arn:aws:s3:::${props.bucket002}`,
                `arn:aws:s3:::${props.bucket003}`,
              ],
              effect: iam.Effect.ALLOW,
            }),
            new iam.PolicyStatement({
              actions: ['logs:*'],
              resources: ['*'],
              effect: iam.Effect.ALLOW,
            }),
          ],
        }),
      },
    });

    const checkS3Lambda = new lambda.Function(this, 'CheckS3Lambda', {
      runtime: lambda.Runtime.PYTHON_3_12,
      handler: 'index.lambda_handler',
      code: lambda.Code.fromInline(`
import boto3

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    bucket = event['bucket']
    resp = s3.list_objects_v2(Bucket=bucket)
    return {'isEmpty': resp.get('KeyCount', 0) == 0}
      `),
      role: checkS3LambdaRole,
      timeout: cdk.Duration.seconds(10),
    });

    const masterRole = new iam.Role(this, 'MasterStepFunctionRole', {
      assumedBy: new iam.ServicePrincipal('states.amazonaws.com'),
      inlinePolicies: {
        MasterStepPolicy: new iam.PolicyDocument({
          statements: [
            new iam.PolicyStatement({
              actions: ['lambda:InvokeFunction', 'states:StartExecution'],
              resources: ['*'],
              effect: iam.Effect.ALLOW,
            }),
          ],
        }),
      },
    });

    const startStep1 = new tasks.StepFunctionsStartExecution(this, 'StartStep1', {
      stateMachine: sfn.StateMachine.fromStateMachineArn(this, 'Step1SM', props.step1Arn),
      integrationPattern: sfn.IntegrationPattern.REQUEST_RESPONSE,
      input: sfn.TaskInput.fromObject({}),
    });

    const wait60 = new sfn.Wait(this, 'Wait60Minutes', {
      time: sfn.WaitTime.duration(cdk.Duration.minutes(60)),
    });

    const raceStep1OrTimeout = new sfn.Parallel(this, 'RaceStep1orTimeout')
      .branch(startStep1)
      .branch(wait60);

    const initVars = new sfn.Pass(this, 'InitPollingVars', {
      result: sfn.Result.fromObject({ count: 0, streak: 0 }),
      resultPath: '$.vars'
    });

    const checkS3_001 = new tasks.LambdaInvoke(this, 'CheckS3_001', {
      lambdaFunction: checkS3Lambda,
      payload: sfn.TaskInput.fromObject({ bucket: props.bucket001 }),
      resultPath: '$.check',
    });

    const incStreak = new sfn.Pass(this, 'IncStreak', {
      parameters: {
        'vars.count.$': '$.vars.count',
        'vars.streak.$': 'States.MathAdd($.vars.streak, 1)',
        'vars.countNext.$': 'States.MathAdd($.vars.count, 1)'
      },
      resultPath: '$.vars',
    });

    const resetStreak = new sfn.Pass(this, 'ResetStreak', {
      parameters: {
        'vars.count.$': '$.vars.count',
        'vars.streak': 0,
        'vars.countNext.$': 'States.MathAdd($.vars.count, 1)'
      },
      resultPath: '$.vars',
    });

    const evalCheck = new sfn.Choice(this, 'EvaluateCheck')
      .when(sfn.Condition.booleanEquals('$.check.Payload.isEmpty', true), incStreak)
      .otherwise(resetStreak);

    const wait1min = new sfn.Wait(this, 'Wait1Minute', {
      time: sfn.WaitTime.duration(cdk.Duration.minutes(1)),
    });

    const fail = new sfn.Fail(this, 'FailWithLog', {
      error: 'S3PollTimeout',
      cause: 'Polling bucket 001 reached 60 attempts without 5 consecutive empty responses.',
    });

    const startStep2 = new tasks.StepFunctionsStartExecution(this, 'StartStep2', {
      stateMachine: sfn.StateMachine.fromStateMachineArn(this, 'Step2SM', props.step2Arn),
      integrationPattern: sfn.IntegrationPattern.REQUEST_RESPONSE,
      input: sfn.TaskInput.fromObject({}),
    });

    const check002 = new tasks.LambdaInvoke(this, 'Check002', {
      lambdaFunction: checkS3Lambda,
      payload: sfn.TaskInput.fromObject({ bucket: props.bucket002 }),
      resultPath: '$.s3Check002',
    });

    const startStep3 = new tasks.StepFunctionsStartExecution(this, 'StartStep3', {
      stateMachine: sfn.StateMachine.fromStateMachineArn(this, 'Step3SM', props.step3Arn),
      integrationPattern: sfn.IntegrationPattern.REQUEST_RESPONSE,
      input: sfn.TaskInput.fromObject({}),
    });

    const step3Decision = new sfn.Choice(this, 'Step3Decision')
      .when(sfn.Condition.booleanEquals('$.s3Check002.Payload.isEmpty', false), startStep3)
      .otherwise(undefined);

    const startStep4 = new tasks.StepFunctionsStartExecution(this, 'StartStep4', {
      stateMachine: sfn.StateMachine.fromStateMachineArn(this, 'Step4SM', props.step4Arn),
      integrationPattern: sfn.IntegrationPattern.REQUEST_RESPONSE,
      input: sfn.TaskInput.fromObject({}),
    });

    const check003 = new tasks.LambdaInvoke(this, 'Check003', {
      lambdaFunction: checkS3Lambda,
      payload: sfn.TaskInput.fromObject({ bucket: props.bucket003 }),
      resultPath: '$.s3Check003',
    });

    const startStep5 = new tasks.StepFunctionsStartExecution(this, 'StartStep5', {
      stateMachine: sfn.StateMachine.fromStateMachineArn(this, 'Step5SM', props.step5Arn),
      integrationPattern: sfn.IntegrationPattern.REQUEST_RESPONSE,
      input: sfn.TaskInput.fromObject({}),
    });

    const step5Decision = new sfn.Choice(this, 'Step5Decision')
      .when(sfn.Condition.booleanEquals('$.s3Check003.Payload.isEmpty', false), startStep5)
      .otherwise(new sfn.Pass(this, 'EndLog', {
        result: sfn.Result.fromString('Workflow Complete'),
        resultPath: '$.result',
      }));

    const checkEnd = new sfn.Choice(this, 'CheckEnd')
      .when(sfn.Condition.numberGreaterThanEquals('$.vars.streak', 5), startStep2)
      .when(sfn.Condition.numberLessThan('$.vars.countNext', 60), wait1min.next(checkS3_001))
      .otherwise(fail);

    const definition = raceStep1OrTimeout
      .next(initVars)
      .next(checkS3_001)
      .next(evalCheck)
      .next(checkEnd);

    new sfn.StateMachine(this, 'MasterStateMachine', {
      stateMachineName: 'master',
      role: masterRole,
      definition,
    });
  }
}

