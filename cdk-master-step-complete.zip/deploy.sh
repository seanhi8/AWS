#!/bin/bash
set -e

# Load variables from .env
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
else
  echo ".env file not found!"
  exit 1
fi

# Run CDK deploy with context variables
cdk deploy \
  -c step1Arn=$STEP1_ARN \
  -c step2Arn=$STEP2_ARN \
  -c step3Arn=$STEP3_ARN \
  -c step4Arn=$STEP4_ARN \
  -c step5Arn=$STEP5_ARN \
  -c bucket001=$BUCKET001 \
  -c bucket002=$BUCKET002 \
  -c bucket003=$BUCKET003
