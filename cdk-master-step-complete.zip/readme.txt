cdk-master-step-complete/
├── .env                         # 可手动修改部署参数
├── deploy.sh                    # 本地部署脚本，自动读取 .env
├── package.json                 # 项目依赖配置
├── tsconfig.json                # TypeScript 配置
├── cdk.json                     # CDK 启动项
├── bin/
│   └── cdk-master-step.ts       # CDK 入口文件
├── lib/
│   └── master-step-function.ts  # Step Function 核心定义
└── .github/
    └── workflows/
        └── deploy.yml           # GitHub Actions 自动部署配置
