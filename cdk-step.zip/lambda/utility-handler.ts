import { S3Client, ListObjectsV2Command } from '@aws-sdk/client-s3';
import { SFNClient, StartExecutionCommand } from '@aws-sdk/client-sfn';

const s3 = new S3Client({});
const stepFunctions = new SFNClient({});
const stateMachineArn = process.env.STATE_MACHINE_ARN;

exports.handler = async (event: any): Promise<any> => {
  const action = event?.action;

  if (action === 'check') {
    const bucket = event?.bucket;
    if (!bucket) throw new Error("Missing 'bucket' parameter");

    const resp = await s3.send(new ListObjectsV2Command({ Bucket: bucket }));
    const isEmpty = (resp.KeyCount || 0) === 0;
    return { isEmpty };

  } else if (action === 'start') {
    if (!stateMachineArn) throw new Error('STATE_MACHINE_ARN not set');
    const result = await stepFunctions.send(new StartExecutionCommand({
      stateMachineArn,
      input: '{}'
    }));
    return { status: 'started', executionArn: result.executionArn };

  } else {
    throw new Error("Invalid action. Use 'check' or 'start'");
  }
};
