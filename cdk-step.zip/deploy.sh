#!/bin/bash

set -e

STACK_NAME="StepFlowStack"

echo "Installing dependencies..."
npm install

echo "Building TypeScript project..."
npm run build

echo "Deploying CDK stack: $STACK_NAME..."
npx cdk deploy $STACK_NAME --require-approval never

echo "Deployment complete."
