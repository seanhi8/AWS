import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as stepfunctions from 'aws-cdk-lib/aws-stepfunctions';
import * as tasks from 'aws-cdk-lib/aws-stepfunctions-tasks';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as path from 'path';

interface MasterStackProps extends cdk.StackProps {
  targetBucket: string;
  step1Arn: string;
  step2Arn: string;
  step3Arn: string;
  step4Arn: string;
  step5Arn: string;
  maxPollCount?: number;
  requiredStreak?: number;
  waitSeconds?: number;
}

export class MasterStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: MasterStackProps) {
    super(scope, id, props);

    const {
      targetBucket,
      step1Arn,
      step2Arn,
      step3Arn,
      step4Arn,
      step5Arn,
      maxPollCount = 60,
      requiredStreak = 5,
      waitSeconds = 60
    } = props;

    // Lambda to handle both "start" and "check"
    const utilityLambda = new lambda.Function(this, 'UtilityLambda', {
      runtime: lambda.Runtime.NODEJS_18_X,
      handler: 'utility-handler.handler',
      code: lambda.Code.fromAsset(path.join(__dirname, '../lambda')),
      timeout: cdk.Duration.seconds(10),
      environment: {
        STATE_MACHINE_ARN: '' // temporary, will be replaced later
      }
    });

    utilityLambda.addToRolePolicy(new iam.PolicyStatement({
      actions: ['s3:ListBucket'],
      resources: [`arn:aws:s3:::${targetBucket}`]
    }));

    utilityLambda.addToRolePolicy(new iam.PolicyStatement({
      actions: ['states:StartExecution'],
      resources: ['*']
    }));

    const stepFunctionRole = new iam.Role(this, 'StepFunctionRole', {
      assumedBy: new iam.ServicePrincipal('states.amazonaws.com')
    });

    stepFunctionRole.addToPolicy(new iam.PolicyStatement({
      actions: ['lambda:InvokeFunction', 'states:StartExecution'],
      resources: ['*']
    }));

    // Wait state reused
    const waitState = new stepfunctions.Wait(this, 'Wait1Minute', {
      time: stepfunctions.WaitTime.duration(cdk.Duration.seconds(waitSeconds))
    });

    const success = new stepfunctions.Pass(this, 'SuccessLog', {
      result: stepfunctions.Result.fromString('Workflow completed successfully'),
      end: true
    });

    const fail = new stepfunctions.Fail(this, 'FailLog', {
      error: 'WorkflowFailed',
      cause: 'An error occurred during execution'
    });

    const startStep1 = new tasks.StepFunctionsStartExecution(this, 'StartStep1', {
      stateMachine: stepfunctions.StateMachine.fromStateMachineArn(this, 'Step1Machine', step1Arn),
      integrationPattern: stepfunctions.IntegrationPattern.REQUEST_RESPONSE,
      resultPath: stepfunctions.JsonPath.DISCARD
    });

    const waitForStep1 = new stepfunctions.Wait(this, 'WaitForStep1', {
      time: stepfunctions.WaitTime.duration(cdk.Duration.seconds(60))
    });

    const initVars = new stepfunctions.Pass(this, 'InitVars', {
      result: stepfunctions.Result.fromObject({ count: 0, streak: 0 }),
      resultPath: '$.vars'
    });

    const checkS3 = new tasks.LambdaInvoke(this, 'PollS3', {
      lambdaFunction: utilityLambda,
      payload: stepfunctions.TaskInput.fromObject({
        action: 'check',
        bucket: targetBucket
      }),
      resultPath: '$.check'
    });

    const incStreak = new stepfunctions.Pass(this, 'IncStreak', {
      parameters: {
        'vars.count.$': '$.vars.count',
        'vars.streak.$': 'States.MathAdd($.vars.streak, 1)',
        'vars.countNext.$': 'States.MathAdd($.vars.count, 1)'
      },
      resultPath: '$.vars'
    });

    const resetStreak = new stepfunctions.Pass(this, 'ResetStreak', {
      parameters: {
        'vars.count.$': '$.vars.count',
        'vars.streak': 0,
        'vars.countNext.$': 'States.MathAdd($.vars.count, 1)'
      },
      resultPath: '$.vars'
    });

    const pollDecision = new stepfunctions.Choice(this, 'PollResultCheck')
      .when(stepfunctions.Condition.booleanEquals('$.check.Payload.isEmpty', true), incStreak)
      .otherwise(resetStreak);

    const pollEndDecision = new stepfunctions.Choice(this, 'CheckPollEnd')
      .when(stepfunctions.Condition.numberGreaterThanEquals('$.vars.streak', requiredStreak), new stepfunctions.Pass(this, 'ContinueToStep2'))
      .when(stepfunctions.Condition.numberLessThan('$.vars.countNext', maxPollCount), waitState)
      .otherwise(fail);

    waitState.next(checkS3);
    incStreak.next(pollEndDecision);
    resetStreak.next(pollEndDecision);
    checkS3.next(pollDecision);

    const step2 = new tasks.StepFunctionsStartExecution(this, 'StartStep2', {
      stateMachine: stepfunctions.StateMachine.fromStateMachineArn(this, 'Step2Machine', step2Arn),
      integrationPattern: stepfunctions.IntegrationPattern.REQUEST_RESPONSE,
      resultPath: stepfunctions.JsonPath.DISCARD
    });

    const checkForStep3 = new tasks.LambdaInvoke(this, 'CheckStep3', {
      lambdaFunction: utilityLambda,
      payload: stepfunctions.TaskInput.fromObject({
        action: 'check',
        bucket: targetBucket
      }),
      resultPath: '$.check2'
    });

    const startStep3 = new tasks.StepFunctionsStartExecution(this, 'StartStep3', {
      stateMachine: stepfunctions.StateMachine.fromStateMachineArn(this, 'Step3Machine', step3Arn),
      integrationPattern: stepfunctions.IntegrationPattern.REQUEST_RESPONSE,
      resultPath: stepfunctions.JsonPath.DISCARD
    });

    const step3Decision = new stepfunctions.Choice(this, 'Step3Decision')
      .when(stepfunctions.Condition.booleanEquals('$.check2.Payload.isEmpty', false), startStep3)
      .otherwise(new stepfunctions.Pass(this, 'SkipStep3'));

    const step4 = new tasks.StepFunctionsStartExecution(this, 'StartStep4', {
      stateMachine: stepfunctions.StateMachine.fromStateMachineArn(this, 'Step4Machine', step4Arn),
      integrationPattern: stepfunctions.IntegrationPattern.REQUEST_RESPONSE,
      resultPath: stepfunctions.JsonPath.DISCARD
    });

    const checkForStep5 = new tasks.LambdaInvoke(this, 'CheckStep5', {
      lambdaFunction: utilityLambda,
      payload: stepfunctions.TaskInput.fromObject({
        action: 'check',
        bucket: targetBucket
      }),
      resultPath: '$.check3'
    });

    const startStep5 = new tasks.StepFunctionsStartExecution(this, 'StartStep5', {
      stateMachine: stepfunctions.StateMachine.fromStateMachineArn(this, 'Step5Machine', step5Arn),
      integrationPattern: stepfunctions.IntegrationPattern.REQUEST_RESPONSE,
      resultPath: stepfunctions.JsonPath.DISCARD
    });

    const step5Decision = new stepfunctions.Choice(this, 'Step5Decision')
      .when(stepfunctions.Condition.booleanEquals('$.check3.Payload.isEmpty', false), startStep5)
      .otherwise(success);

    const definition = stepfunctions.Chain
      .start(startStep1)
      .next(waitForStep1)
      .next(initVars)
      .next(checkS3)
      .next(pollDecision)
      .next(step2)
      .next(checkForStep3)
      .next(step3Decision)
      .next(step4)
      .next(checkForStep5)
      .next(step5Decision)
      .next(success);

    const stateMachine = new stepfunctions.StateMachine(this, 'MasterStateMachine', {
      definition,
      role: stepFunctionRole
    });

    // Inject the actual ARN into the Lambda env
    utilityLambda.addEnvironment('STATE_MACHINE_ARN', stateMachine.stateMachineArn);

    new cdk.CfnOutput(this, 'MasterStateMachineArn', {
      value: stateMachine.stateMachineArn
    });
  }
}
