cdk-stepflow/
├── bin/
│   └── cdk-stepflow.ts          # CDK entry
├── lib/
│   └── master-stack.ts          # 主栈定义
├── lambda/
│   └── utility-handler.ts       # 合并后的 Lambda 代码
├── cdk.json
├── package.json
└── tsconfig.json

# 安装依赖
npm install

# 构建项目
npm run build

# 部署栈
npx cdk deploy
